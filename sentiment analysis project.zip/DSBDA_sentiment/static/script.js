    // Your JavaScript code here
    function showPieChart() {
        var product = document.getElementById('product-select').value;
        if (!product) {
            alert('Please select a product.');
            return;
        }
        fetch('/sentiment', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ product: product })
        })
        .then(response => response.json())
        .then(data => {
            if (Object.keys(data).length === 0) {
                alert('Data not found for selected product.');
                return;
            }
            var chartData = {
                values: Object.values(data),
                labels: Object.keys(data),
                type: 'pie',
                hoverinfo: 'label+percent+name',
                textinfo: 'none',
                marker: {
                    colors: [
                        'red',
                        'blue',
                        'green'
                    ],
                    borderColor: [
                        'red',
                        'green',
                        'blue'
                    ],
                    borderWidth: 1
                }
            };

            var layout = {
                title: 'Sentiment Distribution',
                height: 400,
                width: 500
            };

            // Plot the chart
            Plotly.newPlot('chart-container', [chartData], layout);

            //feedback
            fetch('/feedback', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ product: product })
            })
            .then(response => response.json())
            .then(feedbackData => {
                var feedbackContainer = document.getElementById('feedback-container');
                feedbackData.forEach(feedback => {
                    var feedbackElement = document.createElement('div');
                    feedbackElement.textContent = feedback;
                    feedbackContainer.appendChild(feedbackElement); // Use appendChild here
                });
            
            })
            .catch(error => {
                console.error('Error fetching feedback:', error);
            });
        })
        .catch(error => {
            console.error('Error:', error);
        });
    }
    