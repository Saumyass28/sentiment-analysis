from flask import Flask, render_template, request, jsonify
import pandas as pd
import json

app = Flask(__name__)

# Read the CSV file and preprocess data
product_sentiment_counts = {
    'All-New Fire HD 8 Tablet, 8 HD Display, Wi-Fi, 16 GB': {'Negative': 163, 'Neutral': 123, 'Positive': 2528},
    'Amazon Fire Tv,,,\\r\\nAmazon Fire Tv,,,': {'Negative': 84, 'Neutral': 98, 'Positive': 2345},
    'Amazon Kindle Paperwhite - eBook reader - 4 GB': {'Negative': 153, 'Neutral': 116, 'Positive': 2907},
    'Echo (White),,,\\r\\nEcho (White),,,': {'Negative': 131, 'Neutral': 144, 'Positive': 3034},
    'Fire Kids Edition Tablet, 7 Display, Wi-Fi, 16': {'Negative': 112, 'Neutral': 66, 'Positive': 1507}
}
negative_reviews_data = {
    'All-New Fire HD 8 Tablet, 8 HD Display, Wi-Fi, 16 GB - Includes Special Offers, Magenta': [
        "Not easy for elderly users because of ads that pop up.",
        "The tablet freezes frequently, making it frustrating to use.",
        "Battery life is shorter than expected."
    ],
    'Amazon Fire Tv,,,\\r\\nAmazon Fire Tv,,,': [
        "Alexa doesn't recognize certain locations.",
        "Setup process is confusing and time-consuming.",
        "Limited functionality compared to expectations."
    ],
    'Amazon Kindle Paperwhite - eBook reader - 4 GB':[
        "Screen is broken.",
        "Brightness is too low.",
        "Quality is not that good."
    ],
    'Echo (White),,,\\r\\nEcho (White),,,':[
        "It is a little hard to figure out how to put togther",
        "Could answer weather questions but functionality is not that good for others",
        "Battery is emptied too fast"
    ],
    'Fire Kids Edition Tablet, 7 Display, Wi-Fi, 16':[
        "Battery life isn't great overall",
        "Limited use",
        "Screen is not well responsive"
    ]
    # Add negative reviews for other products...
}
# Process negative reviews and generate feedback
common_themes_by_product = {}
for product_name, negative_reviews in negative_reviews_data.items():
    common_themes = {}
    for review in negative_reviews:
        tokens = review.lower().split()
        for keyword in ['quality', 'functionality', 'customer service', 'shipping', 'price', 'battery']:
            if keyword in tokens:
                common_themes[keyword] = common_themes.get(keyword, 0) + 1
    common_themes_by_product[product_name] = common_themes

occurrences_by_product = {}
for product_name, themes in common_themes_by_product.items():
    occurrences = {theme: count for theme, count in themes.items()}
    occurrences_by_product[product_name] = occurrences

suggestions_by_product = {}
for product_name, occurrences in occurrences_by_product.items():
    suggestions = {}
    for theme, count in occurrences.items():
        if theme == 'quality':
            suggestions[theme] = "Consider improving product quality control processes."
        elif theme == 'functionality':
            suggestions[theme] = "Enhance product features and performance."
        elif theme == 'customer service':
            suggestions[theme] = "Investigate and address customer service issues promptly to improve satisfaction."
        elif theme == 'shipping':
            suggestions[theme] = "Optimize shipping processes to reduce delivery times and minimize errors."
        elif theme == 'price':
            suggestions[theme] = "Evaluate pricing strategy to ensure competitiveness in the market."
        elif theme == 'battery':
            suggestions[theme] = "Optimize the battery life more."
    suggestions_by_product[product_name] = suggestions

feedback_by_product = {}
for product_name, suggestions in suggestions_by_product.items():
    feedback = f"\nFeedBack:"
    for theme, suggestion in suggestions.items():
        feedback += f"\n\n{theme.capitalize()}: {suggestion}\n"
    feedback_by_product[product_name] = feedback
# Home route
@app.route('/')
def home():
    return render_template('index.html')


# API endpoint to get sentiment data for a selected product
@app.route('/sentiment', methods=['POST'])
def get_sentiment():
    selected_product = request.json['product']
    if selected_product in product_sentiment_counts:
        return json.dumps(product_sentiment_counts[selected_product])
    else:
        return json.dumps({})

# API endpoint to get feedback for a selected product
@app.route('/feedback', methods=['POST'])
def get_feedback():
    selected_product = request.json['product']
    print(selected_product)
    if selected_product in negative_reviews_data:
        print("hello")
        feedback_string = feedback_by_product[selected_product]
        print(feedback_string)
        print(type(feedback_string))
        feedback_array = feedback_string.split('\n')
        print(feedback_array)
        print(type(feedback_array))
        return jsonify(feedback_array)
    else:
        print('Hi')
        return jsonify([])

    

if __name__ == '__main__':
    app.run(debug=True)
